import api from './client';
import type {
  GameStatusOut,
  InventoryOut,
  ProcurementMemoryOut,
  ProductionMemoryOut,
  LeaderboardOut,
  Source,
  ComponentSlotData,
  MarketFaction,
  FinancesData,
  TransportOut,
  CostProjectionOut,
  NotificationOut,
  BackroomStatusOut,
  CycleBriefingOut,
} from '../types';

// Thin wrapper around backend endpoints. No hardcoded data.
export const teamApi = {
  // Team auth is lightweight; backend may not strictly validate here.
  login: async (teamId: number, pin: string) => {
    const { data } = await api.post(
      "/team/login",
      {}, // empty body
      {
        headers: {
          "x-team-id": teamId,
          "x-team-pin": pin,
        },
      }
    );

    return {
      team_id: data.team_id,
      team_name: data.team_name,
    };
  },

  // Public status endpoint (no auth headers required)
  status: async (): Promise<GameStatusOut> => {
    const { data } = await api.get<GameStatusOut>('/team/status', {
      // Ensure no auth headers are forced (interceptor adds only if present)
    });
    return data;
  },

  // Team inventory/me
  me: async (): Promise<InventoryOut> => {
    const { data } = await api.get<InventoryOut>('/team/me');
    return data;
  },

  // Sources catalog — if not available on backend, this should be wired when provided.
  // Fallback to procurement GET if sources are embedded elsewhere.
  getSources: async (component?: string): Promise<Source[]> => {
    const params = component ? { component } : undefined;
    const { data } = await api.get<Source[]>('/team/procurement/sources', { params });
    return data;
  },

  getTransports: async (): Promise<Record<string, TransportOut>> => {
    const { data } = await api.get<Record<string, TransportOut>>('/team/procurement/transports');
    return data;
  },

  // Procurement memory
  getProcurement: async (): Promise<ProcurementMemoryOut> => {
    const { data } = await api.get<ProcurementMemoryOut>('/team/procurement');
    return data;
  },

  projectProcurementCosts: async (decisions: Record<string, any>): Promise<CostProjectionOut> => {
    const { data } = await api.post<CostProjectionOut>('/team/procurement/project', { decisions });
    return data;
  },

  // PATCH semantics: caller should pass only changed fields
  patchProcurement: async (decisions: Record<string, any>) => {
    const { data } = await api.patch('/team/procurement', { decisions });
    return data;
  },

  // Production memory
  getProduction: async (): Promise<ProductionMemoryOut> => {
    const { data } = await api.get<ProductionMemoryOut>('/team/production');
    return data;
  },

  patchProduction: async (payload: any) => {
    const { data } = await api.patch('/team/production', payload);
    return data;
  },

  // Sales memory and updates
  getSales: async () => {
    const { data } = await api.get('/team/sales');
    return data;
  },

  patchSales: async (payload: any) => {
    const { data } = await api.patch('/team/sales', payload);
    return data;
  },

  getSalesPrices: async (): Promise<{
    scrap: number;
    rework: number;
    black_market: number;
    substandard: number;
    standard: number;
    premium: number;
  }> => {
    const { data } = await api.get('/team/sales/prices');
    return data;
  },

  projectSalesAssembly: async (units: number): Promise<{ 
    projected_distribution: number[]; 
    bottleneck_component: string; 
    max_possible: number; 
  }> => {
    const { data } = await api.post('/team/sales/projections', { units_to_assemble: units });
    return data;
  },

  // Public leaderboard (works only during backroom/game_over)
  getLeaderboard: async (): Promise<LeaderboardOut> => {
    const { data } = await api.get<LeaderboardOut>('/team/leaderboard');
    return data;
  },

  // Missing factory endpoints
  getComponents: async () => {
    const { data } = await api.get<{ 
      drone_stock: number[]; 
      drone_stock_total: number; 
      components: ComponentSlotData[] 
    }>('/team/inventory/components');
    return data;
  },

  getMachines: async (comp: string) => {
    const { data } = await api.get<ComponentSlotData>(`/team/inventory/machines/${comp}`);
    return data;
  },

  getProcurementSummary: async () => {
    const { data } = await api.get('/team/procurement/summary');
    return data;
  },

  getProductionSummary: async () => {
    const { data } = await api.get('/team/production/summary');
    return data;
  },

  getSalesSummary: async () => {
    const { data } = await api.get('/team/sales/summary');
    return data;
  },

  getFinances: async (): Promise<FinancesData> => {
    const { data } = await api.get<FinancesData>('/team/finances');
    return data;
  },

  getMarket: async (): Promise<{ factions: MarketFaction[] }> => {
    const { data } = await api.get<{ factions: MarketFaction[] }>('/team/market');
    return data;
  },

  // Notifications & Backroom
  getNotifications: async (): Promise<NotificationOut[]> => {
    const { data } = await api.get<NotificationOut[]>('/team/events/notifications');
    return data;
  },

  getNews: async (): Promise<any[]> => {
    const { data } = await api.get<any[]>('/team/events/news');
    return data;
  },

  getBackroomStatus: async (): Promise<BackroomStatusOut> => {
    const { data } = await api.get<BackroomStatusOut>('/team/events/backroom-status');
    return data;
  },

  buyIntel: async () => {
    const { data } = await api.post('/team/events/buy-intel');
    return data;
  },

  getTeamMembers: async (): Promise<any[]> => {
    const { data } = await api.get<any[]>('/team/members');
    return data;
  },

  addTeamMember: async (name: string, role?: string): Promise<any> => {
    const { data } = await api.post('/team/members', { name, role });
    return data;
  },
  getBriefing: async (): Promise<CycleBriefingOut> => {
    const { data } = await api.get<CycleBriefingOut>('/team/briefing');
    return data;
  }
};